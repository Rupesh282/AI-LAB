location for minimax bot              : Desdemona/bots/MyBot/bot.so
location for minimax with pruning bot : Desdemona/bots/MyBotabp/bot.so
