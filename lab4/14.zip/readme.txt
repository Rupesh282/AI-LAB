# to run the main.cc file, 
run command : 
$ ./run.sh <input_file>


output will be generated in output.txt file
