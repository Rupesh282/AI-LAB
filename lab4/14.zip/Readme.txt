# How to run our program : 

# To compile the main.cc , 
run command :
$ make compile

# To run the program with input 'file' , 
run command : 
$ ./run.sh file

# output will be generated in output.txt file

#to clean up generated files
$ make clean
