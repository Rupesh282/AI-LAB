g++ main.cc -o main
./main < $1 > output.txt
