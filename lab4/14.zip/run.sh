./main < $1 > output.txt

