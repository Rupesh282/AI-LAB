# how to run the 14.py

type in terminal : 
$ python3 14.py <name of kernel>

Ex : 
$ python3 14.py rbf
$ python3 14.py linear
$ python3 14.py poly