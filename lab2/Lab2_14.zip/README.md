> NOTE : You don't need to provide input to program. Program will generate its own random input and run the algorigthm.

# How to run BFS.cc : 
run following command in terminal for compiling the program BFS.cc <br>
$ g++ BFS.cc -o bfs  <br>
then run the executable using following command : <br>
$ ./bfs


<br>

# How to run HillClimbing.cc : 
run following command in terminal for compiling the program BFS.cc <br>
$ g++ HillClimbing.cc -o hillclimbing <br>
then run the executable using following command : <br>
$ ./hillclimbing

> NOTE : output will contain start state, goal state and explored states. <br> If we reach at goal state, it will be mentioned at end of output.
